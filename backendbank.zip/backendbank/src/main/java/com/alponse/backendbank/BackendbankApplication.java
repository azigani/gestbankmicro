package com.alponse.backendbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendbankApplication.class, args);
	}

}
